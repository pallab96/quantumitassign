<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-6 offset-sm-4 mt-5">
            <h2>Welcome, <?php echo e(Auth::user()->name); ?>!</h2>
        </div>
        <div class="col-lg-5 section">
            <div>
                Total Companies
                <h2 class="mt-3"><?php echo e($total_c); ?></h2>
            </div>
        </div>
        <div class="col-lg-5 section">
            <div>
                Total Employees
                <h2 class="mt-3"><?php echo e($total_e); ?></h2>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
    <style>
        .section{
            -webkit-box-shadow: 0 30px 60px 0 rgba(0,0,0,0.3);
            box-shadow: 0 30px 60px 0 rgba(0,0,0,0.3);
            padding: 20px;
            border-radius: 5px;
            margin: 20px;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /srv/http/quantumit/resources/views/index.blade.php ENDPATH**/ ?>